package com.example.td

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
